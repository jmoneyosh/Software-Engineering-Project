﻿using UnityEngine;

public class floats : MonoBehaviour
{
    bool up = true;
    void Update()
    {
        if (up)
        {
            transform.Translate(new Vector3(0,1,0) * Time.deltaTime);
            if(this.transform.position.y > 3)
                up = false;
        }
        else
        {
            transform.Translate(new Vector3(0,-1, 0) * Time.deltaTime);
            if(this.transform.position.y < 2)
                up = true;
        }
            
    }
}
