﻿namespace Assets._scripts
{
    public class Stats
    {
        public int MAXHP;
        public int cur_hp;
        public int atk;
        public int def;
        public int spd;
        public Stats() { }
    }
}
