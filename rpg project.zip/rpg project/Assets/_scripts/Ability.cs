﻿namespace Assets._scripts
{
    public class Ability
    {
        public string name;
        public int power;
        public int acc;
        public int statAcc;
    }
}
