﻿using UnityEngine;

namespace Assets._scripts
{
    public class BattleFLow : MonoBehaviour {

        public Monster active_mem;
        public Monster enemy;
        public PlayerCharacter player;
        string[] abilities = System.IO.File.ReadAllLines("ability.txt");
        bool turn;
        // Use this for initialization
        void Start () {


	    }

        //method that executes the follow of choosing an attack and doing said attack
        void attack()
        {
            Ability abil= chooseAbility();
            int power = attackPower(abil);
        }

        //Allows player to choose the ability to be used
        Ability chooseAbility()
        {
            Ability retAbil = null;
            if (turn)
            {
    //TODO implementation for choosing an ability        
            }
            else
            {
                retAbil = enemy.abilityList[UnityEngine.Random.Range(0, 5)];
            }
            return retAbil;
        }

        //Given a ceratin Ability, the power and whether the move hits is determined
        int attackPower(Ability ability)
        {
            if ((ability.acc + active_mem.accBuff) < UnityEngine.Random.Range(1, 100))
                return 0;
            if (turn)
                return (ability.power * active_mem.stats.atk) - enemy.stats.def;
            else
                return (ability.power * enemy.stats.atk) - active_mem.stats.def;
        }

        // Update is called once per frame
        void Update () {
	
	    }
    }
}

