﻿using UnityEngine;
using System.Collections;

public class BattleFLow : MonoBehaviour {

    public characterbehaviour player;
    public characterbehaviour enemy;
    bool turn;
    // Use this for initialization
    void Start () {


	}

    void setAbilities()
    {
        string[] abilities = System.IO.File.ReadAllLines("ability.txt");

    }

    //method that executes the follow of choosing an attack and doing said attack
    void attack()
    {
        Ability abil= chooseAbility();
        int power = attackPower(abil);
    }

    //Allows player to choose the ability to be used
    Ability chooseAbility()
    {
        Ability retAbil = null;
        return retAbil;
    }

    //Given a ceratin Ability, the power and whether the move hits is determined
    int attackPower(Ability ability)
    {
        if ((ability.acc + player.accBuff) < UnityEngine.Random.Range(1, 100))
            return 0;
        return ability.power;
    }

    // Update is called once per frame
    void Update () {
	
	}
}
