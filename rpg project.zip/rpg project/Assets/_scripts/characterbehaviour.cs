﻿using UnityEngine;
using UnityEngine.UI;

namespace Assets._scripts
{
    public class characterbehaviour : MonoBehaviour
    {
        public Text hud;
        public Text player_name;
        Monster mon = new Monster();
        bool up = true;

        string inputFile = "players.txt";
        void Start()
        {
            mon.setUpStats(this.tag,inputFile);
            setHud();
        }

    //An animation function
        void floats(){
            if (up)
                {
                    transform.Translate(new Vector3(0, 1, 0) * Time.deltaTime);
                    if (this.transform.position.y > 3)
                        up = false;
                }
                else
                {
                    transform.Translate(new Vector3(0, -1, 0) * Time.deltaTime);
                    if (this.transform.position.y < 2)
                        up = true;
                }
        }

        void rotate(){
            transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
        }
    
    //
        void Update(){
            if (this.tag == "Capsle")
                floats();
            else if (this.tag == "Cube")
                rotate();
        }

    //Display health. Will be called after an attack to show updated health.
        void setHud()
        {
            player_name.text = mon.name;
            hud.text = "HP: " + mon.stats.cur_hp.ToString() + "/" + mon.stats.MAXHP.ToString();
        }
    }
}

