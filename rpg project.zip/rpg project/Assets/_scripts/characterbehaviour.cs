﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Linq;

public class Ability
{
    public string name;
    public int power;
    public int acc;
    public int statAcc;
}

public class Stats
{
    public int MAXHP;
    public int cur_hp;
    public int atk;
    public int def;
    public int spd;
    public Stats() { }
}

public class characterbehaviour : MonoBehaviour
{
    public Text hud;
    public Text player_name;
    const int abilityLimit = 4;

    public Ability[] abilityList = new Ability[abilityLimit];
    public int
    public Stats stats = new Stats();

    public int accBuff = 0;
    bool up = true;

    void Start()
    {
        setUpStats(this.tag);
        player_name.text = this.tag;
        setHud();
    }

    void setUpAbility()
    {

    }

//function for leveling up player or monsters 
//TODO implement this function
    void levelUp()
    {

    }

//method for determining if a move will hit and the damage the move will do.
//
    int attackPower(Ability ability)
    {
        if ((ability.acc + accBuff) < UnityEngine.Random.Range(1, 100))
            return 0;
        return ability.power;
    }

    void setUpStats(string name)
    {
        string[] monsters = System.IO.File.ReadAllLines("players.txt");
        int idx = 0;
        for(int i = 0; i < monsters.Length; i+=5)
        {
            if (monsters[i] == name)
                idx = i;
        }
        player_name.text = monsters[idx];
        stats.MAXHP = Int32.Parse(monsters[idx + 1]);
        stats.cur_hp = stats.MAXHP;
        stats.atk = Int32.Parse(monsters[idx + 2]);
        stats.def = Int32.Parse(monsters[idx + 3]);
        stats.spd = Int32.Parse(monsters[idx + 4]);
    }

//An animation function
    void floats(){
        if (up)
            {
                transform.Translate(new Vector3(0, 1, 0) * Time.deltaTime);
                if (this.transform.position.y > 3)
                    up = false;
            }
            else
            {
                transform.Translate(new Vector3(0, -1, 0) * Time.deltaTime);
                if (this.transform.position.y < 2)
                    up = true;
            }
    }

    void rotate(){
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
    }
    
//
    void Update(){
        if (this.tag == "Capsle")
            floats();
        else if (this.tag == "Cube")
            rotate();
    }

//Display health. Will be called after an attack to show updated health.
    void setHud()
    {
        hud.text = "HP: " + stats.cur_hp.ToString() + "/" + stats.MAXHP.ToString();
    }
}
