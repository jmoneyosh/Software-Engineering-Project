﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets._scripts
{
    public class Monster
    {
        public string name = "";
        public int accBuff = 0;
        const int abilityLimit = 4;
        public Ability[] abilityList = new Ability[abilityLimit];
        public Stats stats = new Stats();

        public void setUpAbility()
        {
            string[] abilities = System.IO.File.ReadAllLines("ability.txt");
        }
        public void setUpStats(string tag, string fileName)
        {
            string[] monsters = System.IO.File.ReadAllLines(fileName);
            int idx = 0;
            for (int i = 0; i < monsters.Length; i += 5)
            {
                if (monsters[i] == tag)
                    idx = i;
            }
            this.name = monsters[idx];
            stats.MAXHP = Int32.Parse(monsters[idx + 1]);
            stats.cur_hp = stats.MAXHP;
            stats.atk = Int32.Parse(monsters[idx + 2]);
            stats.def = Int32.Parse(monsters[idx + 3]);
            stats.spd = Int32.Parse(monsters[idx + 4]);

            setUpAbility();
        }

        //function for leveling up player or monsters 
        //TODO implement this function
        void levelUp()
        {

        }
    }
}
