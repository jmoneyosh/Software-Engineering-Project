﻿using System;

namespace Assets._scripts
{
    public class PlayerCharacter
    {
        private const int party_limit = 6;
        public Monster[] party = new Monster[party_limit];
        public String name;
    }
}
