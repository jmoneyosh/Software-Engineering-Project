﻿using UnityEngine;
using System.Collections;

public class camera_behavior : MonoBehaviour {
	
	void Update () {
        transform.rotation.SetFromToRotation(new Vector3(0,3,-10), new Vector3(0,3,10));
	}
}
